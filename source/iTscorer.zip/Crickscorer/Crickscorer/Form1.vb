﻿Imports System.Data.SqlClient
Imports AForge.Video
Imports System.Threading


Public Class Form1
    Public Touchless As New TouchlessLib.TouchlessMgr
    Public Camera1 As TouchlessLib.Camera = Touchless.Cameras.ElementAt(0)
    Dim pball1(10), prun1(10), brun1(10), bwic1(10), trun1, w1 As Integer
    Dim pname1(10), bname1(10) As String
    Dim four(10), six(10), four1(10), six1(10), p, q As Integer
    Dim extra, extra1, bover(10), bmid(10) As Integer
    Dim a, b, g As Integer
    Dim pdot(10), bdot(10), bover1(10) As Integer
    Dim pnl As Integer
    Dim pball(10), prun(10), brun(10), bwic(10), trun, w, i, j, n As Integer
    Dim over, tover, ocount, osum(10), osum1(10) As Integer
    Dim i1, j1, temp, extrass, extrass1, tov As Integer
    Dim tempo, tempo1 As Double
    Dim pname(10), bname(10) As String
    Dim teamio As String
    Dim s1 As String = "("
    Dim s2 As String = ")"
    Dim SAPI As Object = CreateObject("SAPI.spvoice")
    Dim rndv, rndr As Integer

    Dim con As SqlConnection = New SqlConnection("Data Source=.\SQLEXPRESS;Database=dbcrickscorer;trusted_connection=true;")
    Dim cmd As SqlCommand
    Dim sql As String
    Dim result As Integer
    Private Sub saveData(sql As String)
        Try
            con.Open()
            cmd = New SqlCommand
            With cmd
                .Connection = con
                .CommandText = sql
                result = .ExecuteNonQuery()
            End With
            If result > 0 Then
                ' MsgBox("Data has been saved in the databse")
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            con.Close()
        End Try
    End Sub
    Private Sub Label47_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub CheckBox4_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox4.CheckedChanged
        If (CheckBox4.Checked = True) Then
            Panel1.BringToFront()
            Panel1.Visible = True
            CheckBox1.Checked = False
            CheckBox3.Checked = False
            CheckBox2.Checked = False
            CheckBox5.Checked = False
            CheckBox6.Checked = False
            Dim my As Integer
            ' Me.Chart3.Titles.Add(teamio)

            Me.Chart1.Series("Runs").Points.Clear()


            For my = 0 To w + 1
                Me.Chart1.Series("Runs").Points.AddXY(pname(my), prun(my))

            Next
        End If
        If (CheckBox4.Checked = False) Then
            Panel1.Visible = False
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        PictureBox2.Visible = False
        VideoSourcePlayer1.Visible = False
        AxWindowsMediaPlayer1.BringToFront()
        Panel3.BringToFront()
        AxWindowsMediaPlayer1.Visible = True
        Label14.BringToFront()
        'Label24.BringToFront()
        Label23.BringToFront()
        Label22.BringToFront()
        'Label21.BringToFront()
        Label20.BringToFront()
        Label19.BringToFront()
        Label18.BringToFront()
        Label17.BringToFront()
        Label25.BringToFront()
        Label26.BringToFront()
        Label46.BringToFront()
        Label47.BringToFront()
        '  Label48.BringToFront()
        ' Label49.BringToFront()
        'Label50.BringToFront()
        'Label51.BringToFront()
        'Label52.BringToFront()
        Label16.BringToFront()
        Label15.BringToFront()
        '  PictureBox1.BringToFront()

        Timer1.Stop()
        ' PictureBox2.Image = Nothing
        OpenFileDialog1.ShowDialog()
        AxWindowsMediaPlayer1.URL = OpenFileDialog1.FileName
        AxWindowsMediaPlayer1.Height = 550
        AxWindowsMediaPlayer1.Width = 1000
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.CheckForIllegalCrossThreadCalls = False
    End Sub

    Private Sub Button22_Click(sender As Object, e As EventArgs) Handles Button22.Click
        Touchless.CurrentCamera = Camera1
        Touchless.CurrentCamera.CaptureHeight = 493
        Touchless.CurrentCamera.CaptureWidth = 852

        PictureBox2.BringToFront()
        VideoSourcePlayer1.Visible = False
        AxWindowsMediaPlayer1.Visible = False
        PictureBox2.Visible = True


        Label14.BringToFront()
        'Label24.BringToFront()
        Label23.BringToFront()
        Label22.BringToFront()
        'Label21.BringToFront()
        Label20.BringToFront()
        Label19.BringToFront()
        Label18.BringToFront()
        Label17.BringToFront()
        Label25.BringToFront()
        Label26.BringToFront()
        Label46.BringToFront()
        Label47.BringToFront()
        '      Label48.BringToFront()
        '     Label49.BringToFront()
        '    Label50.BringToFront()
        '   Label51.BringToFront()
        '  Label52.BringToFront()
        Label16.BringToFront()
        Label15.BringToFront()

        AxWindowsMediaPlayer1.URL = Nothing
        a = 1
        Timer1.Enabled = True
        PictureBox2.Image = Touchless.CurrentCamera.GetCurrentImage
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If a = 1 Then
            PictureBox2.Image = Touchless.CurrentCamera.GetCurrentImage
        End If
    End Sub

    Private Sub Button23_Click(sender As Object, e As EventArgs) Handles Button23.Click
        Timer1.Stop()
        ' PictureBox2.Image = Nothing
        PictureBox2.Visible = False
        VideoSourcePlayer1.Visible = False
        ' AxWindowsMediaPlayer1.URL = Nothing
        AxWindowsMediaPlayer1.Visible = False
        Label14.BringToFront()
        '    Label24.BringToFront()
        Label23.BringToFront()
        Label22.BringToFront()
        '   Label21.BringToFront()
        Label20.BringToFront()
        Label19.BringToFront()
        Label18.BringToFront()
        Label17.BringToFront()
        Label25.BringToFront()
        Label26.BringToFront()
        Label46.BringToFront()
        Label47.BringToFront()
        '  Label48.BringToFront()
        ' Label49.BringToFront()
        'Label50.BringToFront()
        'Label51.BringToFront()
        'Label52.BringToFront()
        Label16.BringToFront()
        Label15.BringToFront()
    End Sub

    Private Sub Label25_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label26_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub TabPage1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs)

    End Sub

    Public Sub TabPage1_Click_1(sender As Object, e As EventArgs)

    End Sub

    Public Sub TabPage2_Click(sender As Object, e As EventArgs)

    End Sub

    Public Sub TabPage6_Click(sender As Object, e As EventArgs)

    End Sub

    Public Sub TabPage7_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        If Label14.Font.Bold = True Or Label15.Font.Bold = True Or Label18.Font.Bold = True Then
            Exit Sub
        End If
        If over > 5 Then
            Exit Sub
        End If
        b = 0
        If TextBox7.Text = " " Or TextBox7.Text = "" Or TextBox7.Text = Nothing Or TextBox7.Text = "  " Then
            Exit Sub
        Else
            Label19.Text += " LB+"
            b = CInt(TextBox7.Text)
            Label19.Text += "" & b
        End If
        TextBox7.Text = " "
        trun = trun + b
        over = over + 1
        extrass = extrass + b
        If over > 5 Then
            ocount = ocount + 1
            Label18.Font = New Font(Label18.Font, FontStyle.Bold)
            Label20.Font = New Font(Label20.Font, FontStyle.Bold)

        End If

        Label47.Text = "" & ocount
        If over = 6 Then
            over = 0
        End If
        Label47.Text += "." & over
        If over = 0 Then
            over = 6
        End If

        If RadioButton1.Checked = True Then
            pball(i) = pball(i) + 1
            If b = 1 Or b = 3 Or b = 5 Then
                RadioButton2.Checked = True
            End If
        End If
        If RadioButton2.Checked = True Then
            pball(j) = pball(j) + 1
            If b = 1 Or b = 3 Or b = 5 Then
                RadioButton1.Checked = True
            End If
        End If
        Label26.Text = "" & trun & s3 & w
        '   Label49.Text = Math.Round((trun / ((ocount * 6) + over)) * 6, 2)
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        If Label14.Font.Bold = True Or Label15.Font.Bold = True Or Label18.Font.Bold = True Then
            Exit Sub
        End If
        If over > 5 Then
            Exit Sub
        End If
        b = 0
        If TextBox7.Text = " " Or TextBox7.Text = "" Or TextBox7.Text = Nothing Or TextBox7.Text = "  " Then
            Exit Sub
        Else
            Label19.Text += " Byes+"
            b = CInt(TextBox7.Text)
            Label19.Text += "" & b
        End If
        TextBox7.Text = " "
        trun = trun + b
        over = over + 1
        extrass = extrass + b
        If over > 5 Then
            ocount = ocount + 1
            Label18.Font = New Font(Label18.Font, FontStyle.Bold)
            Label20.Font = New Font(Label20.Font, FontStyle.Bold)

        End If

        Label47.Text = "" & ocount
        If over = 6 Then
            over = 0
        End If
        Label47.Text += "." & over
        If over = 0 Then
            over = 6
        End If
        If RadioButton1.Checked = True Then
            pball(i) = pball(i) + 1
            If b = 1 Or b = 3 Or b = 5 Then
                RadioButton2.Checked = True
            End If
        End If
        If RadioButton2.Checked = True Then
            pball(j) = pball(j) + 1
            If b = 1 Or b = 3 Or b = 5 Then
                RadioButton1.Checked = True
            End If
        End If
        Label26.Text = "" & trun & s3 & w
        ' Label49.Text = Math.Round((trun / ((ocount * 6) + over)) * 6, 2)
    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        If Label14.Font.Bold = True Or Label15.Font.Bold = True Or Label18.Font.Bold = True Then
            Exit Sub
        End If
        If over > 5 Then
            Exit Sub
        End If
        b = 0
        If TextBox7.Text = Nothing Then
            Label19.Text += " NoBall "

        Else
            Label19.Text += " NoBall+"
            b = CInt(TextBox7.Text)
            Label19.Text += "" & b
        End If
        TextBox7.Text = " "
        trun = trun + 1 + b
        extrass = extrass + b + 1
        If RadioButton1.Checked = True Then
            If b = 1 Or b = 3 Or b = 5 Then
                RadioButton2.Checked = True
            End If
        End If
        If RadioButton2.Checked = True Then
            If b = 1 Or b = 3 Or b = 5 Then
                RadioButton1.Checked = True
            End If
        End If
        Label26.Text = "" & trun & s3 & w
        'Label49.Text = Math.Round((trun / ((ocount * 6) + over)) * 6, 2)
    End Sub

    Private Sub Button14_Click(sender As Object, e As EventArgs) Handles Button14.Click
        If over > 5 Then
            Exit Sub
        End If

        If Label14.Font.Bold = True Then
            Exit Sub
        End If
        If Label15.Font.Bold = True Then
            Exit Sub
        End If
        If Label18.Font.Bold = True Then
            Exit Sub
        End If

        b = 0
        If TextBox7.Text = Nothing Then
            Label19.Text += " W "
        Else
            Label19.Text += " W+"
            b = CInt(TextBox7.Text)
            Label19.Text += "" & b
        End If
        TextBox7.Text = " "
        If RadioButton1.Checked Then

            prun(i) = prun(i) + b
            pball(i) = pball(i) + 1
            Label16.Text = "" & prun(i) & s1 & pball(i) & s2
            Label14.Font = New Font(Label14.Font, FontStyle.Bold)
            Label16.Font = New Font(Label16.Font, FontStyle.Bold)
            'Label50.Text = Math.Round((prun(i) / pball(i)) * 100, 2)

        ElseIf RadioButton2.Checked Then

            pball(j) = pball(j) + 1
            prun(j) = prun(j) + b
            Label17.Text = "" & prun(j) & s1 & pball(j) & s2
            Label15.Font = New Font(Label15.Font, FontStyle.Bold)
            Label17.Font = New Font(Label17.Font, FontStyle.Bold)
            'Label51.Text = Math.Round((prun(j) / pball(j)) * 100, 2)

        End If
        If over = 6 Then
            Label18.Font = New Font(Label18.Font, FontStyle.Bold)
            Label20.Font = New Font(Label20.Font, FontStyle.Bold)

        End If
        w = w + 1
        bwic(n) = bwic(n) + 1
        ' Label47.Text += ".0"

        trun = trun + b
        If RadioButton1.Checked = True Then
            If b = 1 Or b = 3 Or b = 5 Then
                RadioButton2.Checked = True
            End If
        End If
        If RadioButton2.Checked = True Then
            If b = 1 Or b = 3 Or b = 5 Then
                RadioButton1.Checked = True
            End If
        End If
        TextBox7.Text = " "
        ' Label47.Text += ".0"
        Label26.Text = "" & trun & s3 & w
        Label20.Text = "" & brun(n) & s3 & bwic(n)
        over = over + 1

        Label47.Text = "" & ocount
        If over = 6 Then
            over = 0
        End If
        Label47.Text += "." & over
        '   Label49.Text = Math.Round((trun / ((ocount * 6) + over)) * 6, 2)
        If over = 0 Then
            over = 6
        End If
        '  Label52.Text = Math.Round((brun(n) / over) * 6, 2)

    End Sub

    Private Sub Button15_Click(sender As Object, e As EventArgs) Handles Button15.Click
        If over > 5 Then
            Exit Sub
        End If

        If Label14.Font.Bold = True Then
            Exit Sub
        End If
        If Label15.Font.Bold = True Then
            Exit Sub
        End If
        If Label18.Font.Bold = True Then
            Exit Sub
        End If


        If RadioButton1.Checked Then


            pball(i) = pball(i) + 1
            Label16.Text = "" & prun(i) & s1 & pball(i) & s2
            Label14.Font = New Font(Label14.Font, FontStyle.Bold)
            Label16.Font = New Font(Label16.Font, FontStyle.Bold)
            'Label50.Text = Math.Round((prun(i) / pball(i)) * 100, 2)

        ElseIf RadioButton2.Checked Then

            pball(j) = pball(j) + 1

            Label17.Text = "" & prun(j) & s1 & pball(j) & s2
            Label15.Font = New Font(Label15.Font, FontStyle.Bold)
            Label17.Font = New Font(Label17.Font, FontStyle.Bold)
            'Label51.Text = Math.Round((prun(j) / pball(j)) * 100, 2)

        End If
        If over = 6 Then
            Label18.Font = New Font(Label18.Font, FontStyle.Bold)
            Label20.Font = New Font(Label20.Font, FontStyle.Bold)

        End If
        w = w + 1
        bwic(n) = bwic(n) + 1
        Label26.Text = "" & trun & s3 & w
        Label20.Text = "" & brun(n) & s3 & bwic(n)
        over = over + 1
        Label19.Text += " W "
        Label47.Text = "" & ocount
        If over = 6 Then
            over = 0
            ' Label47.Text += ".0"

        End If
        Label47.Text += "." & over
        'Label49.Text = Math.Round((trun / ((ocount * 6) + over)) * 6, 2)
        If over = 0 Then
            over = 6
        End If
        'Label52.Text = Math.Round((brun(n) / over) * 6, 2)

    End Sub

    Private Sub Label27_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub TabControl1_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub PictureBox2_Click_1(sender As Object, e As EventArgs)

    End Sub

    Private Sub Chart1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub TabPage3_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub TabControl2_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label41_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label37_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label38_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label39_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label40_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label42_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label43_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label44_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label45_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label32_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label28_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label30_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label31_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label33_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label34_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label29_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label36_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub TabPage4_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub TabPage5_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub LinkLabel2_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs)

    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs)

    End Sub

    Private Sub Label60_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label59_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label58_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label57_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label54_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label53_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub

    Private Sub Button25_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button26_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub ToolTip1_Popup(sender As Object, e As PopupEventArgs) Handles ToolTip1.Popup

    End Sub

    Private Sub Button24_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label20_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click

    End Sub

    Private Sub Label6_Click(sender As Object, e As EventArgs) Handles Label6.Click

    End Sub

    Private Sub Label48_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label7_Click(sender As Object, e As EventArgs) Handles Label7.Click

    End Sub

    Private Sub Label21_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label8_Click(sender As Object, e As EventArgs) Handles Label8.Click

    End Sub

    Private Sub Label19_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub Label46_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged

    End Sub

    Private Sub Label49_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs) Handles TextBox3.TextChanged

    End Sub

    Private Sub Label22_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label9_Click(sender As Object, e As EventArgs) Handles Label9.Click

    End Sub

    Private Sub OpenFileDialog1_FileOk(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles OpenFileDialog1.FileOk

    End Sub

    Private Sub Label18_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label12_Click(sender As Object, e As EventArgs) Handles Label12.Click

    End Sub

    Private Sub Label23_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label11_Click(sender As Object, e As EventArgs) Handles Label11.Click

    End Sub

    Private Sub Label17_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label10_Click(sender As Object, e As EventArgs) Handles Label10.Click

    End Sub

    Private Sub Label24_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub TextBox5_TextChanged(sender As Object, e As EventArgs) Handles TextBox5.TextChanged

    End Sub

    Private Sub TextBox4_TextChanged(sender As Object, e As EventArgs) Handles TextBox4.TextChanged

    End Sub

    Private Sub Label15_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label13_Click(sender As Object, e As EventArgs) Handles Label13.Click

    End Sub

    Private Sub TextBox6_TextChanged(sender As Object, e As EventArgs) Handles TextBox6.TextChanged

    End Sub

    Private Sub Label51_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label14_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label52_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label50_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label16_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub TextBox7_TextChanged(sender As Object, e As EventArgs) Handles TextBox7.TextChanged

    End Sub

    Private Sub Label55_Click(sender As Object, e As EventArgs) Handles Label55.Click

    End Sub

    Public Sub TabPage8_Click(sender As Object, e As EventArgs)

    End Sub

    Public Sub TabPage9_Click(sender As Object, e As EventArgs)

    End Sub


    Dim thedatatable As New DataTable
    Dim thedatatable1 As New DataTable
    Dim bowldatatable As New DataTable
    Dim bowldatatable1 As New DataTable
    Dim thedatafow As New DataTable
    Dim thedatafow1 As New DataTable

    Private Sub Button28_Click(sender As Object, e As EventArgs)

        Dim my, asp, nm As Integer
        '   If i1 = 0 Or j1 = 0 Then
        '  Exit Sub
        ' End If
        If pname1(0) = Nothing Then
            Exit Sub
        End If
        If nm = 1 Then
            Exit Sub
        End If
        If asp = 1 Then
            Exit Sub
        End If
        If asp = 0 Then
            With thedatatable1
                .Columns.Add("Name", System.Type.GetType("System.String"))
                .Columns.Add("Runs", System.Type.GetType("System.String"))
                .Columns.Add("Balls", System.Type.GetType("System.String"))
                .Columns.Add("4s", System.Type.GetType("System.String"))
                .Columns.Add("6s", System.Type.GetType("System.String"))
                .Columns.Add("SR", System.Type.GetType("System.String"))
            End With
            asp = 1
        End If

        '     If i1 > j1 Then
        '    till = i1
        '   Else
        '  till = j1
        ' End If
        For my = 0 To w1 + 1
            Dim newrow1 As DataRow = thedatatable1.NewRow
            newrow1("Name") = pname1(my)
            newrow1("Runs") = prun1(my)
            newrow1("Balls") = pball1(my)
            newrow1("4s") = four1(my)
            newrow1("6s") = six1(my)
            newrow1("SR") = Math.Round((prun1(my) / pball1(my)) * 100, 2)
            thedatatable1.Rows.Add(newrow1)
            '    DataGridView1.DataSource = thedatatable1

        Next
        nm = 1

        '  Label28.Text = TextBox5.Text
        ' Label29.Text = "" & trun1 - 1 & s3 & w1
        'Label33.Text = tempo1
        ' Label38.Text = extrass1
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub



    Public Sub TabPage10_Click(sender As Object, e As EventArgs)

    End Sub

    Public Sub TabPage11_Click(sender As Object, e As EventArgs)

    End Sub


    Private Sub DataGridView3_CellContentClick(sender As Object, e As DataGridViewCellEventArgs)

    End Sub

    Private Sub DataGridView2_CellContentClick(sender As Object, e As DataGridViewCellEventArgs)

    End Sub

    Private Sub Button16_Click(sender As Object, e As EventArgs)
        OpenFileDialog2.ShowDialog()
        ''PictureBox3.Load(OpenFileDialog2.FileName)
    End Sub

    Private Sub AxWindowsMediaPlayer1_Enter(sender As Object, e As EventArgs) Handles AxWindowsMediaPlayer1.Enter

    End Sub
    Dim displ As Integer = 0
    Private Sub Timer3_Tick(sender As Object, e As EventArgs) Handles Timer3.Tick

        displ = displ + 1
        If (displ = 50) Then
            Timer3.Enabled = False
            PictureBox1.Visible = False
            displ = 0

        End If



    End Sub

    Private Sub Button16_Click_2(sender As Object, e As EventArgs) Handles Button16.Click
        Dim sourceURL As String = TextBox8.Text
        sourceURL += "/video?800x450"
        PictureBox2.Visible = False
        AxWindowsMediaPlayer1.Visible = False

        Dim mjpeg As MJPEGStream = New MJPEGStream(sourceURL)
        VideoSourcePlayer1.Visible = True
        VideoSourcePlayer1.VideoSource = mjpeg
        VideoSourcePlayer1.Start()
        VideoSourcePlayer1.BringToFront()
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If (CheckBox1.Checked = True) Then
            CheckBox5.Checked = False
            CheckBox3.Checked = False
            CheckBox4.Checked = False
            CheckBox2.Checked = False
            CheckBox6.Checked = False
            Panel3.BringToFront()
            Timer2.Enabled = True
            Panel3.Visible = True

        End If
        If (CheckBox1.Checked = False) Then
            Panel3.Visible = False
            Panel3.Top = Panel3.Top + 50
            pnl = 0
        End If
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        pnl = pnl + 10
        Panel3.Top = Panel3.Top - 10
        If (pnl = 50) Then
            Timer2.Enabled = False

        End If

    End Sub
    Dim asp As Integer = 0
    Private Sub CheckBox3_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox3.CheckedChanged
        If (CheckBox3.Checked = True) Then
            Panel8.BringToFront()
            Panel8.Visible = True
            CheckBox1.Checked = False
            CheckBox2.Checked = False
            CheckBox4.Checked = False
            CheckBox5.Checked = False
            CheckBox6.Checked = False
            DataGridView3.ColumnHeadersVisible = False
            Dim my As Integer
asas:
            For Each row As DataGridViewRow In DataGridView3.Rows

                DataGridView3.Rows.Remove(DataGridView3.CurrentRow)

            Next
            If DataGridView3.Rows.Count > 1 Then
                GoTo asas
            End If
            If asp = 0 Then
                With bowldatatable
                    .Columns.Add("Name", System.Type.GetType("System.String"))
                    .Columns.Add("Over", System.Type.GetType("System.String"))
                    .Columns.Add("Maidens", System.Type.GetType("System.String"))
                    .Columns.Add("Dots", System.Type.GetType("System.String"))
                    .Columns.Add("Runs", System.Type.GetType("System.String"))
                    .Columns.Add("Wickets", System.Type.GetType("System.String"))
                    .Columns.Add("Economy", System.Type.GetType("System.String"))

                End With
                asp = 1
            End If
            For my = 0 To ocount
                Dim newrow As DataRow = bowldatatable.NewRow
                newrow("Name") = bname(my)
                If bover(my) > 0 Or bover(my) = 0 Then
                    ' Bball(10) ****
                    newrow("Over") = bover(my) + (over / 10)
                Else

                    newrow("Over") = bover(my)
                End If
                newrow("Maidens") = bmid(my)
                newrow("Dots") = bdot(my)
                newrow("Runs") = brun(my)
                newrow("Wickets") = bwic(my)
                If over > 0 And bover(my) = 0 Then
                    newrow("Economy") = Math.Round((brun(my) / (bover(my) * 6)) * 6, 2)

                Else
                    newrow("Economy") = Math.Round((brun(my) / ((bover(my) * 6) + over)) * 6, 2)
                End If
                bowldatatable.Rows.Add(newrow)
                DataGridView3.DataSource = bowldatatable
            Next
        End If
        If (CheckBox3.Checked = False) Then
            Panel8.Visible = False

        End If
    End Sub

    Private Sub CheckBox5_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox5.CheckedChanged
        If (CheckBox5.Checked = True) Then
            Panel2.BringToFront()
            Panel2.Visible = True
            CheckBox1.Checked = False
            CheckBox3.Checked = False
            CheckBox4.Checked = False
            CheckBox2.Checked = False
            CheckBox6.Checked = False
            Dim My As Integer
            Me.Chart3.Series(0).Points.Clear()

            For My = 0 To w + 1

                Me.Chart3.Series(0).Points.AddXY(pname(My), prun(My))

            Next
        End If
        If (CheckBox5.Checked = False) Then
            Panel2.Visible = False
        End If
    End Sub

    Private Sub Chart6_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub CheckBox6_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox6.CheckedChanged
        If (CheckBox6.Checked = True) Then
            Panel9.BringToFront()
            Panel9.Visible = True
            CheckBox1.Checked = False
            CheckBox3.Checked = False
            CheckBox4.Checked = False
            CheckBox5.Checked = False
            CheckBox2.Checked = False
            Me.Chart2.Series("Myteam").Points.Clear()
            Me.Chart2.Series("Myteam1").Points.Clear()


            Dim my As Integer
            For my = 1 To tover

                Me.Chart2.Series("Myteam").Points.AddXY(my, osum(my - 1))
            Next

            For my = 1 To tover

                Me.Chart2.Series("Myteam1").Points.AddXY(my, osum1(my - 1))
            Next
        End If
        If (CheckBox6.Checked = False) Then
            Panel9.Visible = False
        End If

    End Sub



    Public Sub ComboBox1_SelectedIndexChanged_1(sender As Object, e As EventArgs)

    End Sub


    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub
    Dim asd As Integer = 0

    Private Sub CheckBox2_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox2.CheckedChanged
        If (CheckBox2.Checked = True) Then

            CheckBox1.Checked = False
            CheckBox3.Checked = False
            CheckBox4.Checked = False
            CheckBox5.Checked = False
            CheckBox6.Checked = False
            Panel6.BringToFront()
            Panel6.Visible = True
            DataGridView2.ColumnHeadersVisible = False
            Label44.Text = teamio
            Label40.Text = "" & trun & s3 & w

            Dim my As Integer
            '   DataGridView2.Rows.Clear()
assd:
            For Each row As DataGridViewRow In DataGridView2.Rows

                DataGridView2.Rows.Remove(DataGridView2.CurrentRow)

            Next
            If DataGridView2.Rows.Count > 1 Then
                GoTo assd
            End If

            If asd = 0 Then
                With thedatatable
                    .Columns.Add("Name", System.Type.GetType("System.String"))
                    .Columns.Add("Runs", System.Type.GetType("System.String"))
                    .Columns.Add("Balls", System.Type.GetType("System.String"))
                    .Columns.Add("4s", System.Type.GetType("System.String"))
                    .Columns.Add("6s", System.Type.GetType("System.String"))
                    .Columns.Add("SR", System.Type.GetType("System.String"))
                End With
                asd = 1

            End If


            '   If i > j Then
            '        till = i
            '     Else
            '          till = j
            '       End If

            For my = 0 To w + 1
                ' If pname(my) = "" Then
                'my = my + 1
                'GoTo assd 
                'End If
                Dim newrow As DataRow = thedatatable.NewRow
                newrow("Name") = pname(my)
                newrow("Runs") = prun(my)
                newrow("Balls") = pball(my)
                newrow("4s") = four(my)
                newrow("6s") = six(my)
                newrow("SR") = Math.Round((prun(my) / pball(my)) * 100, 2)
                thedatatable.Rows.Add(newrow)
                DataGridView2.DataSource = thedatatable
            Next

            tempo = ocount + (over / 10)
            'Label62.Text = extrass
            'Label39.Text = tempo
            'Label44.Text = teamio



        End If
        If (CheckBox2.Checked = False) Then
            Panel6.Visible = False

        End If
    End Sub


    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs)
        '  DataGridView1.BackColor = Color.FromArgb(120, 244, 212, 210)
    End Sub

    Private Sub Panel6_Paint(sender As Object, e As PaintEventArgs)
        'Panel6.BackColor = Color.FromArgb(120, 244, 212, 210)
    End Sub

    Private Sub Panel7_Paint(sender As Object, e As PaintEventArgs)
        'Panel7.BackColor = Color.FromArgb(120, 244, 212, 210)
    End Sub

    Private Sub Panel8_Paint(sender As Object, e As PaintEventArgs)
        'Panel8.BackColor = Color.FromArgb(120, 244, 212, 210)
    End Sub

    Private Sub Panel9_Paint(sender As Object, e As PaintEventArgs)
        ' Panel9.BackColor = Color.FromArgb(120, 244, 212, 210)
    End Sub

    Private Sub ListView1_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub

    Dim s3 As String = "-"
    Public Property DataGrid1 As Object

    Private Sub Button20_Click(sender As Object, e As EventArgs) Handles Button20.Click
        Dim io As Integer
        For io = 0 To w + 1
            sql = "INSERT INTO Playerinfo (Tname,Pname,Runs,Balls,Four,Six,SR) VALUES ('" & TextBox5.Text & "','" & pname(io) & "','" & prun(io) & "','" & pball(io) & "','" & four(io) & "','" & six(io) & "','" & (prun(io) / pball(io)) * 100 & "')"
            saveData(sql)
        Next
        For io = 0 To ComboBox3.Items.Count
            sql = "INSERT INTO Bowlerinfo (Tname,Bname,BRuns,BOver,Economy,SR) VALUES ('" & TextBox5.Text & "','" & bname(io) & "','" & brun(io) & "','" & bover(io) & "','" & (brun(io) / bover(io)) & "','" & (brun(io) / bover(io)) * 100 & "')"
            saveData(sql)
        Next


    End Sub

    Function RUNS(ByVal run As Integer) As Integer
        ' Thread.Sleep(1000)
        If TextBox1.Text = "" Then
            Me.ErrorProvider1.SetError(Me.TextBox1, "Enter Player Name")
            Exit Function

        End If
        Me.ErrorProvider1.Clear()
        If TextBox2.Text = "" Then
            Me.ErrorProvider1.SetError(Me.TextBox2, "Enter Player Name")
            Exit Function

        End If
        Me.ErrorProvider1.Clear()
        If TextBox3.Text = "" Then
            Me.ErrorProvider1.SetError(Me.TextBox3, "Enter Player Name")
            Exit Function

        End If
        Me.ErrorProvider1.Clear()
        If over > 5 Then
            'Label19.Text = ""
            Exit Function
        End If
        If Label14.Font.Bold = True Or Label15.Font.Bold = True Or Label18.Font.Bold = True Then

            Exit Function
        End If
        Label19.Text += " " & run
        If RadioButton1.Checked Then

            pball(i) = pball(i) + 1
            prun(i) = prun(i) + run
            trun = trun + run
            If run = 4 Then
                four(i) = four(i) + 1
            End If
            If run = 6 Then
                six(i) = six(i) + 1
            End If
            If run = 0 Then
                pdot(i) = pdot(i) + 1
            End If
            'Label50.Text = Math.Round((prun(i) / pball(i)) * 100, 2)
            Label16.Text = "" & prun(i) & s1 & pball(i) & s2
            If run = 1 Or run = 3 Or run = 5 Then
                RadioButton2.Checked = True
            End If
        ElseIf RadioButton2.Checked Then

            pball(j) = pball(j) + 1
            prun(j) = prun(j) + run
            trun = trun + run
            If run = 4 Then
                four(j) = four(j) + 1
            End If
            If run = 6 Then
                six(j) = six(j) + 1
            End If
            If run = 0 Then
                pdot(j) = pdot(j) + 1
            End If
            'Label51.Text = Math.Round((prun(j) / pball(j)) * 100, 2)
            Label17.Text = "" & prun(j) & s1 & pball(j) & s2
            If run = 1 Or run = 3 Or run = 5 Then
                RadioButton1.Checked = True
            End If
        End If

        brun(n) = brun(n) + run
        If run = 0 Then
            bdot(n) = bdot(n) + 1
        End If
        Label26.Text = "" & trun & s3 & w
        Label20.Text = "" & brun(n) & s3 & bwic(n)
        'Label49.Text = ""
        over = over + 1
        If over > 5 Then
            osum(g) = trun - tov
            tov = trun
            g = g + 1
            ocount = ocount + 1
            If tov = 0 Then
                bmid(n) = bmid(n) + 1
            End If
            Label18.Font = New Font(Label18.Font, FontStyle.Bold)
            Label20.Font = New Font(Label20.Font, FontStyle.Bold)

        End If

        Label47.Text = "" & ocount
        If over = 6 Then
            over = 0
            ' Label47.Text += ".0"

        End If
        Label47.Text += "." & over
        'Label49.Text = Math.Round((trun / ((ocount * 6) + over)) * 6, 2)

        If over = 0 Then
            over = 6
        End If
        If bover(n) > 0 Then
            '   Label52.Text = Math.Round((brun(n) / ((bover(n) * 6) + over)) * 6, 2)
        Else
            '  Label52.Text = Math.Round((brun(n) / over) * 6, 2)
        End If
        '   If CheckBox7.Checked Then
        '  runComentry(run)
        ' End If
        If trun1 > trun And trun > 0 And trun1 > 0 And tover = ocount Then

            Label25.Text = " " & TextBox5.Text
            Label25.Text += " is WON the Match"
            Exit Function

        End If
        If trun1 = trun + 1 And trun > 0 And trun1 > 0 And tover = ocount Then

            ''Label25.Text = " " & TextBox5.Text
            Label25.Text += "The Match is DRAW!!"
            Exit Function

        End If
        If trun1 < trun + 1 And trun1 > 0 And trun > 0 Then
            Label25.Text = " " & TextBox4.Text
            Label25.Text += " is WON the Match"
            Exit Function
        End If
        If tover = ocount And trun1 = 0 Then
            trun1 = trun
            trun1 = trun1 + 1
            Label25.Text = TextBox4.Text
            Label25.Text += " needs " & trun1
            Label25.Text += " runs to Win"
            ocount = 0
            Label19.Text = " "

            pname.CopyTo(pname1, 0)
            pball.CopyTo(pball1, 0)
            prun.CopyTo(prun1, 0)
            bname.CopyTo(bname1, 0)
            brun.CopyTo(brun1, 0)
            bwic.CopyTo(bwic1, 0)
            osum.CopyTo(osum1, 0)
            four.CopyTo(four1, 0)
            six.CopyTo(six1, 0)
            bover.CopyTo(bover1, 0)
            Array.Clear(bover, 0, 10)
            Array.Clear(four, 0, 10)
            Array.Clear(four, 0, 10)
            Array.Clear(osum, 0, 10)
            Array.Clear(pname, 0, 10)
            Array.Clear(pball, 0, 10)
            Array.Clear(prun, 0, 10)
            Array.Clear(bname, 0, 10)
            Array.Clear(bwic, 0, 10)
            Array.Clear(brun, 0, 10)
            w1 = w
            teamio = TextBox4.Text
            extrass1 = extrass
            tempo1 = tempo
            tempo = 0
            tov = 0
            g = 0
            extrass = 0
            over = 0
            trun = 0
            w = 0
            i = 0
            w = 0
            j = 0
            n = 0
            Label14.Font = New Font(Label14.Font, FontStyle.Bold)
            Label15.Font = New Font(Label15.Font, FontStyle.Bold)
            Label16.Font = New Font(Label16.Font, FontStyle.Bold)
            Label17.Font = New Font(Label17.Font, FontStyle.Bold)
            Label18.Font = New Font(Label18.Font, FontStyle.Bold)
            Label20.Font = New Font(Label20.Font, FontStyle.Bold)
            Label25.Font = New Font(Label25.Font, FontStyle.Bold)


            ' Exit Function
            'GoTo Line1
        End If


    End Function


    ''Radio Box ************
    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged

        If RadioButton1.Checked Then
            Label14.Text = "*" + TextBox1.Text
            Panel4.BackColor = System.Drawing.Color.FromArgb(0, 0, 0, 0.5)
            Panel5.BackColor = System.Drawing.Color.FromArgb(100, 100, 100, 100)
        Else
            Label14.Text = TextBox1.Text
        End If

    End Sub

    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton2.CheckedChanged

        If RadioButton2.Checked Then
            Label15.Text = "*" + TextBox3.Text
            Panel5.BackColor = System.Drawing.Color.FromArgb(0, 0, 0, 0.5)
            Panel4.BackColor = System.Drawing.Color.FromArgb(100, 50, 50, 100)
        Else
            Label15.Text = TextBox3.Text
        End If
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        If TextBox1.Text = "" Then
            Me.ErrorProvider1.SetError(Me.TextBox1, "Enter Player Name")
            Exit Sub
        End If
        Me.ErrorProvider1.Clear()
        If TextBox2.Text = "" Then
            Me.ErrorProvider1.SetError(Me.TextBox2, "Enter Player Name")
            Exit Sub
        End If
        Me.ErrorProvider1.Clear()
        If TextBox3.Text = "" Then
            Me.ErrorProvider1.SetError(Me.TextBox3, "Enter Player Name")
            Exit Sub
        End If
        Me.ErrorProvider1.Clear()
        If TextBox4.Text = "" Then
            Me.ErrorProvider1.SetError(Me.TextBox4, "Enter Team Name")
            Exit Sub
        End If
        Me.ErrorProvider1.Clear()
        If TextBox5.Text = "" Then
            Me.ErrorProvider1.SetError(Me.TextBox5, "Enter Team Name")
            Exit Sub
        End If
        Me.ErrorProvider1.Clear()
        If Not IsNumeric(Me.TextBox6.Text) Then
            Me.ErrorProvider1.SetError(Me.TextBox6, "Enter Total Overs")
            Exit Sub
        End If
        Me.ErrorProvider1.Clear()
        If RadioButton1.Checked = False And RadioButton2.Checked = False Then
            Me.ErrorProvider1.SetError(Me.RadioButton1, "Select Strick")
            Exit Sub
        End If
        Me.ErrorProvider1.Clear()
        Label14.Text = "*" + TextBox1.Text
        Label14.Text = TextBox1.Text
        Label15.Text = TextBox3.Text
        Label18.Text = TextBox2.Text
        Label22.Text = TextBox5.Text
        Label23.Text = TextBox4.Text
        Label25.Text = TextBox5.Text + " Elected to bat first!!"
        RadioButton1.Text = TextBox1.Text
        RadioButton2.Text = TextBox3.Text
        tover = CInt(TextBox6.Text)
        'Label21.Text = tover
        Label16.Text = "0(0)"
        Label17.Text = "0(0)"
        Label20.Text = "0-0"
        Label26.Text = "0-0"
        Label19.Text = " "
        'Label50.Text = "0"
        'Label51.Text = "0"
        'Label52.Text = "0"
        'Label49.Text = "0"
        Label19.Text = ""
        Label22.Font = New Font(Label22.Font, FontStyle.Bold)
        i = 0
        j = 1
        pname(i) = TextBox1.Text
        pname(j) = TextBox3.Text
        bname(n) = TextBox2.Text
        teamio = TextBox5.Text
        ComboBox3.Items.Add(bname(n))
    End Sub
    Private Sub Button17_Click(sender As Object, e As EventArgs) Handles Button17.Click
        Label14.Text = " "
        Label15.Text = " "
        Label18.Text = " "
        Label22.Text = " "
        Label23.Text = " "
        'Label21.Text = " "
        Label47.Text = "0"
        RadioButton1.Text = " "
        RadioButton2.Text = " "
        Label16.Text = "0(0)"
        Label17.Text = "0(0)"
        Label20.Text = "0(0)"
        Label26.Text = "0-0"
        '    Label50.Text = "0"
        '   Label51.Text = "0"
        '  Label52.Text = "0"
        ' Label49.Text = "0"

    End Sub

    Private Sub Button18_Click(sender As Object, e As EventArgs) Handles Button18.Click
        Label14.Font = New Font(Label14.Font, FontStyle.Bold)
        Label15.Font = New Font(Label15.Font, FontStyle.Bold)
        Label16.Font = New Font(Label16.Font, FontStyle.Bold)
        Label17.Font = New Font(Label17.Font, FontStyle.Bold)
        Label18.Font = New Font(Label18.Font, FontStyle.Bold)
        Label20.Font = New Font(Label20.Font, FontStyle.Bold)
        Label25.Font = New Font(Label25.Font, FontStyle.Bold)

        If trun1 = trun + 1 And trun > 0 And trun1 > 0 Or tover = ocount Then

            Label25.Text = " "
            Label25.Text += "The Match is DRAW!!"
            Exit Sub

        End If
        If trun1 > trun And trun > 0 And trun1 > 0 Or tover = ocount Then

            Label25.Text = " " & TextBox5.Text
            Label25.Text += " is WON the Match"
            Exit Sub

        End If

        If trun1 < trun And trun1 > 0 And trun > 0 Then
            Label25.Text = " " & TextBox4.Text
            Label25.Text += " is WON the Match"
            Exit Sub
        End If
        trun1 = trun
        temp = trun
        tempo = ocount + (over / 10)
        trun1 = trun1 + 1
        Label25.Text = " " & trun1
        Label25.Text += " runs to Win"

        'Label23.Font = New Font(Label23.Font, FontStyle.Bold)
        'Label22.Font = New Font(Label22.Font, FontStyle.Regular)
        pname.CopyTo(pname1, 0)
        pball.CopyTo(pball1, 0)
        prun.CopyTo(prun1, 0)
        bname.CopyTo(bname1, 0)
        brun.CopyTo(brun1, 0)
        bwic.CopyTo(bwic1, 0)
        osum.CopyTo(osum1, 0)
        four.CopyTo(four1, 0)
        six.CopyTo(six1, 0)
        bover.CopyTo(bover1, 0)
        Array.Clear(bover, 0, 10)
        Array.Clear(four, 0, 10)
        Array.Clear(four, 0, 10)
        Array.Clear(osum, 0, 10)
        Array.Clear(pname, 0, 10)
        Array.Clear(pball, 0, 10)
        Array.Clear(prun, 0, 10)
        Array.Clear(bname, 0, 10)
        Array.Clear(bwic, 0, 10)
        Array.Clear(brun, 0, 10)
        w1 = w
        teamio = TextBox4.Text
        extrass1 = extrass
        tempo1 = tempo
        tempo = 0
        g = 0
        tov = 0
        over = 0
        trun = 0
        w = 0
        i1 = i
        j1 = j
        i = 0
        w = 0
        j = 0
        n = 0
        TextBox1.Text = ""
        TextBox3.Text = ""
        TextBox2.Text = ""

    End Sub


    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        rndv = Int(Rnd() * SAPI.getvoices.Count)
        rndr = Int(Rnd() * 10)
        Dim th2 = New Thread(Sub() Me.runComentry(3, rndr, rndv))
        th2.Start()
        RUNS(3)

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        rndv = Int(Rnd() * SAPI.getvoices.Count)
        rndr = Int(Rnd() * 5)
        Dim th2 = New Thread(Sub() Me.runComentry(5, rndr, rndv))
        th2.Start()
        RUNS(5)


    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        PictureBox1.BringToFront()
        PictureBox1.Visible = True
        PictureBox1.Image = My.Resources.bf9b1ad61a5361c4997aaf844b783b_unscreen
        Timer3.Enabled = True
        rndv = Int(Rnd() * SAPI.getvoices.Count)
        rndr = Int(Rnd() * 25)
        Dim th2 = New Thread(Sub() Me.runComentry(4, rndr, rndv))
        th2.Start()
        RUNS(4)

        'PictureBox1.Visible = False
    End Sub
    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        rndv = Int(Rnd() * SAPI.getvoices.Count)
        rndr = Int(Rnd() * 10)
        Dim th2 = New Thread(Sub() Me.runComentry(2, rndr, rndv))
        th2.Start()
        RUNS(2)

    End Sub
    Private Sub Button12_Click(sender As Object, e As EventArgs) Handles Button12.Click
        PictureBox1.BringToFront()
        PictureBox1.Visible = True
        PictureBox1.Image = My.Resources.w_dribbble_unscreen
        Timer3.Enabled = True

        If over > 5 Then
            Exit Sub
        End If

        If Label14.Font.Bold = True Then
            Exit Sub
        End If
        If Label15.Font.Bold = True Then
            Exit Sub
        End If
        If Label18.Font.Bold = True Then
            Exit Sub
        End If


        If RadioButton1.Checked Then


            pball(i) = pball(i) + 1
            Label16.Text = "" & prun(i) & s1 & pball(i) & s2
            Label14.Font = New Font(Label14.Font, FontStyle.Bold)
            Label16.Font = New Font(Label16.Font, FontStyle.Bold)
            'Label50.Text = Math.Round((prun(i) / pball(i)) * 100, 2)

        ElseIf RadioButton2.Checked Then

            pball(j) = pball(j) + 1

            Label17.Text = "" & prun(j) & s1 & pball(j) & s2
            Label15.Font = New Font(Label15.Font, FontStyle.Bold)
            Label17.Font = New Font(Label17.Font, FontStyle.Bold)
            'Label51.Text = Math.Round((prun(j) / pball(j)) * 100, 2)

        End If
        If over = 6 Then
            Label18.Font = New Font(Label18.Font, FontStyle.Bold)
            Label20.Font = New Font(Label20.Font, FontStyle.Bold)

        End If
        w = w + 1
        bwic(n) = bwic(n) + 1
        Label26.Text = "" & trun & s3 & w
        Label20.Text = "" & brun(n) & s3 & bwic(n)
        over = over + 1
        Label19.Text += " W "
        Label47.Text = "" & ocount
        If over = 6 Then
            over = 0
            ' Label47.Text += ".0"

        End If
        Label47.Text += "." & over
        'Label49.Text = Math.Round((trun / ((ocount * 6) + over)) * 6, 2)
        If over = 0 Then
            over = 6
        End If
        'Label52.Text = Math.Round((brun(n) / over) * 6, 2)


    End Sub



    Private Sub Button13_Click(sender As Object, e As EventArgs) Handles Button13.Click
        If Label14.Font.Bold = True Or Label15.Font.Bold = True Or Label18.Font.Bold = True Then
            Exit Sub
        End If
        If over > 5 Then
            Exit Sub
        End If
        b = 0
        If TextBox7.Text = Nothing Then
            Label19.Text += " Wide "

        Else
            Label19.Text += " Wide+"
            b = CInt(TextBox7.Text)
            Label19.Text += "" & b
        End If
        TextBox7.Text = " "
        trun = trun + 1 + b
        extrass = extrass + b + 1
        If RadioButton1.Checked = True Then
            If b = 1 Or b = 3 Or b = 5 Then
                RadioButton2.Checked = True
            End If
        End If
        If RadioButton2.Checked = True Then
            If b = 1 Or b = 3 Or b = 5 Then
                RadioButton1.Checked = True
            End If
        End If
        Label26.Text = "" & trun & s3 & w
        'Label49.Text = Math.Round((trun / ((ocount * 6) + over)) * 6, 2)
    End Sub

    Private Sub Label35_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button19_Click(sender As Object, e As EventArgs) Handles Button19.Click

        If Label14.Font.Bold = True And Label15.Font.Bold = True And Label18.Font.Bold = True Then
            Label19.Text = ""
            Label47.Text = "0.0"
            'Label49.Text = "0"
            'Label52.Text = "0"


        End If
        If over > 5 Then

            '  osum(g) = trun - tov
            ' tov = trun
            'g = g + 1
            'ocount = ocount + 1
            bover(n) = bover(n) + 1
            Dim asd As Integer
            n = n + 1
            'Label52.Text = "0"
            If ComboBox3.SelectedItem = "" Then
                Label18.Text = TextBox2.Text

                bname(n) = TextBox2.Text
                ComboBox3.Items.Add(bname(n))
            Else
                For asd = 0 To ocount
                    If ComboBox3.SelectedItem = bname(asd) Then
                        Label18.Text = bname(asd)
                        n = asd
                        bover(n) = bover(n) + 1
                        TextBox2.Text = ComboBox3.SelectedItem

                    End If
                Next
            End If


            Label18.Font = New Font(Label18.Font, FontStyle.Regular)
            Label18.Font = New Font(Label18.Font, FontStyle.Regular)
            Label20.Text = "" & brun(n) & s3 & bwic(n)
            over = 0
            Label19.Text = " "
            If RadioButton1.Checked Then
                RadioButton2.Checked = True

            ElseIf RadioButton2.Checked Then
                RadioButton1.Checked = True
            End If
        End If

        'If Label14.Font.Bold = False Or Label15.Font.Bold = False Then
        'Exit Sub
        'End If
        Dim mx As Integer

        'Line1:
        If RadioButton1.Checked And Label14.Font.Bold = True Then

            If Label25.Font.Bold = True Then
                Label23.Font = New Font(Label23.Font, FontStyle.Bold)
                Label22.Font = New Font(Label22.Font, FontStyle.Regular)
                '' Label26.Text = "" & trun & s3 & w
                Label25.Font = New Font(Label25.Font, FontStyle.Regular)
                ''j = i + 2
                j = 1
                'Label51.Text = "0"
                pname(j) = TextBox3.Text
                prun(j) = 0
                pball(j) = 0
                Label15.Text = pname(j)
                RadioButton2.Text = pname(j)
                Label17.Text = "" & prun(j) & s1 & pball(j) & s2
                i = 0


            Else
                If i > j Then
                    mx = i
                Else
                    mx = j
                End If
                i = mx + 1
            End If
            pname(i) = TextBox1.Text
            'Label50.Text = "0"
            prun(i) = 0
            pball(i) = 0
            Label14.Text = pname(i)
            RadioButton1.Text = pname(i)
            Label16.Text = "" & prun(i) & s1 & pball(i) & s2
            Label14.Text = "*" + TextBox1.Text
            Label14.Font = New Font(Label14.Font, FontStyle.Regular)
            Label16.Font = New Font(Label16.Font, FontStyle.Regular)

        ElseIf RadioButton2.Checked And Label15.Font.Bold = True Then
            If Label25.Font.Bold = True Then
                Label23.Font = New Font(Label23.Font, FontStyle.Bold)
                Label22.Font = New Font(Label22.Font, FontStyle.Regular)
                '' Label21.Text = "" & trun & s3 & w
                Label25.Font = New Font(Label25.Font, FontStyle.Regular)
                ''i = j + 1
                i = 0
                '  Label50.Text = "0"
                pname(i) = TextBox1.Text
                prun(i) = 0
                pball(i) = 0
                Label14.Text = pname(i)
                RadioButton1.Text = pname(i)
                Label16.Text = "" & prun(i) & s1 & pball(i) & s2
                j = 1

            Else
                If i > j Then
                    mx = i
                Else
                    mx = j
                End If

                j = mx + 1
            End If
            pname(j) = TextBox3.Text
            'Label51.Text = "0"
            prun(j) = 0
            pball(j) = 0
            Label15.Text = pname(j)
            RadioButton2.Text = pname(j)
            Label17.Text = "" & prun(j) & s1 & pball(j) & s2
            Label15.Text = "*" + TextBox3.Text
            Label17.Font = New Font(Label17.Font, FontStyle.Regular)
            Label15.Font = New Font(Label15.Font, FontStyle.Regular)
        End If

        Label26.Text = "" & trun & s3 & w
        Label18.Text = TextBox2.Text
        Label20.Text = "" & brun(n) & s3 & bwic(n)
        Label14.Font = New Font(Label14.Font, FontStyle.Regular)
        Label15.Font = New Font(Label15.Font, FontStyle.Regular)
        Label16.Font = New Font(Label16.Font, FontStyle.Regular)
        Label17.Font = New Font(Label17.Font, FontStyle.Regular)
        Label18.Font = New Font(Label18.Font, FontStyle.Regular)
        Label20.Font = New Font(Label20.Font, FontStyle.Regular)
        Label25.Font = New Font(Label25.Font, FontStyle.Regular)

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        PictureBox1.BringToFront()
        PictureBox1.Visible = True
        PictureBox1.Image = My.Resources.bb150c5bcee83148b6b67881e92391_unscreen
        Timer3.Enabled = True
        rndv = Int(Rnd() * SAPI.getvoices.Count)
        rndr = Int(Rnd() * 20)
        Dim th2 = New Thread(Sub() Me.runComentry(6, rndr, rndv))
        th2.Start()
        RUNS(6)

    End Sub



    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        rndv = Int(Rnd() * SAPI.getvoices.Count)
        rndr = Int(Rnd() * 15)
        Dim th2 = New Thread(Sub() Me.runComentry(1, rndr, rndv))
        th2.Start()
        RUNS(1)

    End Sub

    Private Sub Button0_Click(sender As Object, e As EventArgs) Handles Button0.Click

        rndv = Int(Rnd() * SAPI.getvoices.Count)
        rndr = Int(Rnd() * 15)
        Dim th2 = New Thread(Sub() Me.runComentry(0, rndr, rndv))
        th2.Start()
        RUNS(0)

    End Sub

    Sub runComentry(run As Integer, i As Integer, x As Integer)

        'Dim SAPI As Object
        'Dim i As Integer
        Dim EnabledSAPI As Short
        ' Dim x As Integer
        Dim msg As String

        '      msg = " " & over + " Tarun to Omkar"
        '      SAPI.speak(msg)
        'SAPI.Speak(msg)
        Try

            If run = 0 Then

                Select Case i
                    Case 0
                        msg = "NO RUN has been taken "
                    Case 1
                        msg = "No Run"
                    Case 2
                        msg = "No Run, Excellent line and length"
                    Case 3
                        msg = "No Run, Fast like bullet"
                    Case 4
                        msg = "No Run, He's Bowling a Good Line and Length"
                    Case 5
                        msg = "Peach of a delivery , No run"
                    Case 6
                        msg = "No Run, Right Up in the Blockhole"
                    Case 7
                        msg = "Run-rate creeping up with every dot ball."
                    Case 8
                        msg = "No Run, That is a brutal ball to get."
                    Case 9
                        msg = "That’s a screamer!, No run"
                    Case 10
                        msg = "What a ball!, No run has been taken"
                    Case 11
                        msg = "What a ball! , No run"
                    Case 12
                        msg = "What a cracking delivery!, No run has been taken"
                    Case 13
                        msg = "What a great delivery! No run has been taken"
                    Case 14
                        msg = "BEATEN! , No run"
                End Select
            ElseIf run = 1 Then

                Select Case i
                    Case 0
                        msg = "One has been taken"
                    Case 1
                        msg = "He has taken just a single"
                    Case 2
                        msg = "Just a single"
                    Case 3
                        msg = "And single has been taken"
                    Case 4
                        msg = "single has been taken easily"
                    Case 5
                        msg = "batsman running hard between the wickets hoping for a Single"
                    Case 6
                        msg = "He ran like a rabbit, Just Single"
                    Case 7
                        msg = "superb running between the wickets by these batsmen, Single taken"
                    Case 8
                        msg = "What a quick single that is !!"
                    Case 9
                        msg = "One easily taken!"
                    Case 10
                        msg = "Taken One run easily"
                    Case 11
                        msg = "Just 1 run has been taken"
                    Case 12
                        msg = "1 run added on scoreboard"
                    Case 13
                        msg = "1 run taken has been taken"
                    Case 14
                        msg = "Just 1 run taken"
                End Select

            ElseIf run = 2 Then

                Select Case i
                    Case 0
                        msg = "2 runs has been taken"
                    Case 1
                        msg = "batsman running hard between the wickets hoping for a second"
                    Case 2
                        msg = "Convert ones into twos"
                    Case 3
                        msg = "He ran like a rabbit, 2 runs taken"
                    Case 4
                        msg = "should be a comfortable 2 there, superb running between the wickets by these batsmen"
                    Case 5
                        msg = "well, pleased should get a couple of runs"
                    Case 6
                        msg = "they will easily get 2 here"
                    Case 7
                        msg = "they will easily get couple of runs here"
                    Case 8
                        msg = "Couple of runs has been taken"
                    Case 9
                        msg = "Just 2 runs taken"

                End Select
            ElseIf run = 3 Then

                Select Case i
                    Case 0
                        msg = "3 runs has been taken"
                    Case 1
                        msg = "can they get three your outstanding fielding saving crucial runs for the team"
                    Case 2
                        msg = "Excellent effort on the boundary, but 3 runs taken"
                    Case 3
                        msg = "Thats sloppy work by the fielder, but 3 runs taken"
                    Case 4
                        msg = "timed well but it's tracked down by the fielder can they get three here"
                    Case 5
                        msg = "they ran like a rabbits, 3 runs taken"
                    Case 6
                        msg = "here they will get 3 easily"
                    Case 7
                        msg = "3 runs taken, nicely"
                    Case 8
                        msg = "batsman running hard between the wickets hoping for third run"
                    Case 9
                        msg = "Nice running between wickets, 3 runs taken"

                End Select
            ElseIf run = 4 Then

                Select Case i
                    Case 0
                        msg = "and finds the boundary, gone for 4"
                    Case 0
                        msg = "and he smashed him down the ground"
                    Case 1
                        msg = "and that's gone to the boundary like a TRACER BULLET"
                    Case 2
                        msg = "Ball goes like a tracer bullet"
                    Case 3
                        msg = "good shot and that will run away for 4"
                    Case 4
                        msg = "If it doesn’t get there, they’ll get 4 runs"
                    Case 5
                        msg = "runs away down towards the rope and finds the boundary, gone 4"
                    Case 6
                        msg = "Shot, for another wonderful boundary, that's 4"
                    Case 7
                        msg = "shot, good enough to go for 4"
                    Case 8
                        msg = "Straight Down the Fielder's Throat."
                    Case 9
                        msg = "that again 4, lovely stroke"
                    Case 10
                        msg = "that is beautiful stroke from batsman"
                    Case 11
                        msg = "that is so beautifully done so easily done, its 4"
                    Case 12
                        msg = " That will go for four as well "
                    Case 13
                        msg = " That would have been a certain four if he had not stopped that. "
                    Case 14
                        msg = "That’ll go for four"
                    Case 15
                        msg = "That’ll run away for another four"
                    Case 16
                        msg = "That's a Proper Cricket Shot"
                    Case 17
                        msg = "that's run away for 4 as simple as that"
                    Case 18
                        msg = "The ball is gonna get to the boundary"
                    Case 19
                        msg = "The ball went to the boundary like a bullet."
                    Case 20
                        msg = "yeah that's beautifully played as well ,that'll run away for 4"
                    Case 21
                        msg = "6 and 4 seems to have become the new Binary Code for this man."
                    Case 22
                        msg = "that's a textbook shot"
                    Case 23
                        msg = "Shot ! that's a textbook shot"
                    Case 24
                        msg = "wow ! What a shot that is ! nice four "
                End Select
            ElseIf run = 5 Then

                Select Case i
                    Case 0
                        msg = "5 runs came for a single ball, wow !!"
                    Case 1
                        msg = "Five runs has been taken, only for single ball"
                    Case 2
                        msg = "Five runs came for 1 ball ! "
                    Case 3
                        msg = "1 ball! five runs, nice"
                    Case 4
                        msg = "5 runs has been from no where"

                End Select
            ElseIf run = 6 Then

                Select Case i
                    Case 0
                        msg = "Shot ! that's a textbook shot, its a Six !"
                    Case 1
                        msg = "Oh he’s hit this one miles, great shot, OHHH IT’S A BIGGIE"
                    Case 2
                        msg = "Magnificent shot, All the way and he goes! "
                    Case 3
                        msg = "and that's gone over the fence"
                    Case 4
                        msg = "Fielder at the boundary will just be a spectator."
                    Case 5
                        msg = "hammered,for six more, "
                    Case 6
                        msg = "He has taken the aerial route"
                    Case 7
                        msg = "Just over the fielder, Six more !!"
                    Case 8
                        msg = "oh godness me he smoked that right on to the embankment , fantastic shot for six"
                    Case 9
                        msg = "oh he hit this one mile, great shot oh it's a biggie"
                    Case 10
                        msg = "oh it's 6, it's huge, it's gone out of the park boom"
                    Case 11
                        msg = "oh this is high, what a six , way down the ground"
                    Case 12
                        msg = "that has disappeared surely came off the middle of the bat wonder where the next one's gonna fly"
                    Case 13
                        msg = "That’s massive and out of the ground"
                    Case 14
                        msg = "Thats a hugeeeee hit! That's Big SIX"
                    Case 15
                        msg = "Six, that's huge! that is a biggie it's outta here!"
                    Case 16
                        msg = "that's massive and out of the ground"
                    Case 17
                        msg = "Six that is, When He Hits It, It Stays Hit."
                    Case 18
                        msg = "IN THE AIR AND JUST OVER! SIX!"
                    Case 19
                        msg = "6 and 4 seems to have become the new Binary Code for this man"

                End Select
            End If
            SAPI.voice = SAPI.getvoices.item(x)

            SAPI.speak(msg)


            EnabledSAPI = EnabledSAPI + 1
        Catch ex As Exception
            SAPI.voice = SAPI.getvoices.item(0)
            msg = "yes its" + msg
            SAPI.speak(msg)
        End Try
    End Sub
End Class